from django.contrib import admin
from .models import Student, Curs
# Register your models here.
admin.site.register(Student)
admin.site.register(Curs)
